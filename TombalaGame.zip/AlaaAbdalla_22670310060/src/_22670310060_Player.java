
public class _22670310060_Player {
    private String name;
    private String cardName;

    public _22670310060_Player(String name, String cardName) {
        this.name = name;
        this.cardName = cardName;
    }

    public String getName() {
        return name;
    }

    public String getCardName() {
        return cardName;
    }
}


